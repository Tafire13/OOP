interface GoodChildren {
    String respecTo(People people);
}
